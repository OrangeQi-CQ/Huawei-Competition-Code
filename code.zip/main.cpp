#include "state.h"
#include "Robot.h"
#include "Workbench.h"
#include "Map.h"
#include "Object.h"
#include "game.h"
#include "Point.h"


#include <iostream>


Game game;


int main() {
    // freopen("input.txt", "r", stdin);
    // freopen("output.txt", "w", stdout);

    game.lets_work();
    return 0;
} 
