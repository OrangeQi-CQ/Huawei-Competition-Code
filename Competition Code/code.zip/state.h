#pragma once
extern int frameID;
extern int current_money;
extern int num_workbench;


