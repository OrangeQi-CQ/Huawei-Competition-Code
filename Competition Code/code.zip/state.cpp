int frameID = 0;
int current_money = 0;
int num_workbench = 0;




