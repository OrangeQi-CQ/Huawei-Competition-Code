#include "Robot.h"
#include "Workbench.h"
#include "Map.h"
#include "Object.h"
#include "game.h"
#include "Point.h"


#include <iostream>


// void GameMap::read_map(Workbench workbench[]) {

// } 

